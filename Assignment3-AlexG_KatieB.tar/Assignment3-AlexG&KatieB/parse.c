#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <glob.h>
#include "sh.h"
#include "mylib.h"
#include "parse.h"
#define max_buf_size 1024
#define tok_buf_size 64
#define MAX_SIZE 2048
#define command_list_size 13


//function for remove new line when commands entered
void rmv_new_line(char* string){
  int len;
  if((len = strlen(string))>0){
    if(string[len-1] == '\n'){
      string[len-1] = '\0';
    }
  }
}

//function for parse
int parse(char* command, char** parameters){
  char *parsed;
  int i =0;
  parsed = strtok(command, " ");
  while(parsed!=NULL && i <= MAX_SIZE){
    parameters[i] = parsed;
    i++;
    parsed = strtok(NULL, " ");
  }
  return i;
}

