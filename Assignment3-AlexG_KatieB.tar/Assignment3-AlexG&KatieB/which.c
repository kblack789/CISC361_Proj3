#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <glob.h>
#include "sh.h"
#include "mylib.h"
#include "which.h"
#define max_buf_size 1024
#define tok_buf_size 64
#define MAX_SIZE 2048
#define command_list_size 13


//Function for which. 
char *which(char *command, struct pathelement *pathlist ){
  while(pathlist->next != NULL){
    char* loc_com = (char *) malloc(max_buf_size);
    strcat(loc_com, pathlist->element);
    strcat(loc_com, "/");
    strcat(loc_com, command);
    if (access(loc_com, F_OK) != -1){
      return loc_com;
    }
    else{
      pathlist = pathlist->next;
    }
  }
  if(pathlist->next == NULL){
    char* loc_com = (char *) malloc(max_buf_size);
    strcpy(loc_com, pathlist->element);
    strcat(loc_com, "/");
    strcat(loc_com, command);
    if(access(loc_com, F_OK) != -1){
      return loc_com;  
    }
    else{
      printf("Command not found.");
      return("");
    }
  }
} 

