#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <glob.h>
#include "sh.h"
#include "mylib.h"
#define max_buf_size 1024
#define tok_buf_size 64
#define MAX_SIZE 2048
#define command_list_size 13

//adds to the doublely linked list that stores all the aliases for the shell.
struct alias_list* add_alias(struct alias_list *head, char** args){
  //takes in char** of args. args[0] is command, args[1] is the alias, args[2+] are the full command
  struct alias_list *temp;
  struct alias_list *new_node = malloc(sizeof(struct alias_list));
  temp = head;
  new_node->alias = malloc(MAX_SIZE);
  new_node->full = malloc(MAX_SIZE);
  strcpy(new_node->alias, args[1]);
  int i = 2;
  char* full_temp = malloc(sizeof(MAX_SIZE));
  while (args[i] != NULL){
    strcat(full_temp, args[i]);
    strcat(full_temp, " ");
    i++;
  }
  strcpy(new_node->full, full_temp);
  new_node->next = NULL;
  if(temp == NULL){
    head = new_node;
  }
  else if(temp->next == NULL){
    temp->next = new_node;
  }
  else{
    while(temp->next != NULL){
      temp = temp->next;
    }
    temp->next = new_node;
  }
  return head;
}

//prints out the list of aliases. This allow them to print each of the aliases side by side with their full commands
void get_alias(struct alias_list *head) {
  struct alias_list *temp = head;
  while(temp!=NULL){
    printf("full command: %s\n", temp->full);
    printf("alias: %s\n", temp->alias);
    temp=temp->next;
  }
}

