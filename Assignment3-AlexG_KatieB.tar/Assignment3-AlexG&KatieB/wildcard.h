#define PROMPTMAX 32
#define MAXARGS 10


int wildcard_check(char *check_string);
char *list_wildcard (char *dir, char* wildcard);
char *command_to_string(char ** args, int arg_count);
int match(char *first, char * second);

