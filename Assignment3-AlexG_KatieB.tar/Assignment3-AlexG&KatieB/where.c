#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <glob.h>
#include "sh.h"
#include "mylib.h"
#include "where.h"
#define max_buf_size 1024
#define tok_buf_size 64
#define MAX_SIZE 2048
#define command_list_size 13


//Function for where
char *where(char *command, struct pathelement *pathlist ){
  char* total_loc = malloc(sizeof(max_buf_size));
  while (pathlist != NULL){
    char* loc_com = malloc(sizeof(max_buf_size));
    strcpy(loc_com, pathlist->element);
    strcat(loc_com, "/");
    strcat(loc_com, command);
    if (access(loc_com, F_OK) != -1){
      strcat(total_loc, loc_com);
      pathlist = pathlist->next;
    }
    else{
      pathlist = pathlist->next;
    }
  }
  if(strcmp(total_loc, "") != 0){
    return(total_loc);
  }
  else{
    return("Command not found.");
  }
}

