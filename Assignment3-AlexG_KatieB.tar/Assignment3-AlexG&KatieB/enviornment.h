#define PROMPTMAX 32
#define MAXARGS 10

void printenv(char **envp);
void set_env(char* envname, char* envval);
void print_env_variable(char *env_var);


