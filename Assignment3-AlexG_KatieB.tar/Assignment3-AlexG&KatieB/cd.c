#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <glob.h>
#include "sh.h"
#include "mylib.h"
#include "cd.h"
#define max_buf_size 1024
#define tok_buf_size 64
#define MAX_SIZE 2048
#define command_list_size 13

//functions for cd
void cd(char *pth, char *prev){
  //append our path to current path
  char *path = malloc(sizeof(*path));
  strcpy(path,pth);
  char cwd[max_buf_size];
  //get current directory to add args to
  getcwd(cwd,sizeof(cwd));
  if (strcmp(path, "..") == 0){
    //printf("%s\n", cwd);
    chdir(cwd);
    return;
  }
  //create string to check
  strcat(cwd,"/");
  if(strcmp(path, "-")==0){
    //strcat(cwd, "..");
    chdir(prev);
    return;
  }
  //if directory is passed in as a whole path form
  if(strstr(path,"/")){
    if(chdir(path)!=0){
      chdir(path);
    }
    return;
  }
  //if not passed in whole path form
  strcat(cwd, path);
  int exists = chdir(cwd);
  if(exists != 0){
    //perror("cd");
  }
  else{
    chdir(cwd);
  }
}

