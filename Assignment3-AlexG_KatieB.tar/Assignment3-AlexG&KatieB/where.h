#define PROMPTMAX 32
#define MAXARGS 10


char *where(char *command, struct pathelement *pathlist);

