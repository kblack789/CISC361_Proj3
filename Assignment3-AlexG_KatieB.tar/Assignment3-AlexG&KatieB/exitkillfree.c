#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <glob.h>
#include "sh.h"
#include "mylib.h"
#include "exitkillfree.h"
#define max_buf_size 1024
#define tok_buf_size 64
#define MAX_SIZE 2048
#define command_list_size 13


//function for shell exit
void shell_exit(){
  exit(0);
}

//function for kill process
void kill_process(char **args, int count){
  if (count == 2){
    kill(atoi(args[1]), SIGKILL);
  }
  else if(strstr(args[1], "-") != NULL){
    kill(atoi(args[2]), atoi(++args[1]));
  }
}

//functions that frees the pathlist when the env of path is changed
void free_pathlist(struct pathelement *head){
  struct pathelement *current = head;
  struct pathelement *temp;
  while(current->next != NULL){
    temp = current;
    current = current->next;
    free(temp);
  }
  free(current);
}

