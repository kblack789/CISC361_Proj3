#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <glob.h>
#include "sh.h"
#include "mylib.h"
#define max_buf_size 1024
#define tok_buf_size 64
#define MAX_SIZE 2048
#define command_list_size 13

//function for add_history. This adds a history command to the double linked list
void add_history(char* command){
  struct history_list *new_node = malloc(sizeof(struct history_list));
  //new_node->node = malloc((sizeof(command)+1));
  new_node->node = malloc(1024);
  strcpy(new_node->node, command);
  new_node->next = NULL;
  new_node->previous = history_tail;
  if(history_tail){
    history_tail->next = new_node;
  }
  history_tail = new_node;
  if(!history_head){
    history_head = new_node;
  }
}

//function for getting history. This prints out the history of the commands given the amount you want to print
void get_history(int i, struct history_list *tail){
  int j = 1;
  while(j<=i && tail!=NULL){
    printf("%s\n",tail->node);
    tail=tail->previous;
    j++;
  }
}