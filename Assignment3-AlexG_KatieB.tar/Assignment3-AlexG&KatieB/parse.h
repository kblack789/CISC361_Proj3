#define PROMPTMAX 32
#define MAXARGS 10


void rmv_new_line(char* string);
int parse(char* command, char** parameters);

