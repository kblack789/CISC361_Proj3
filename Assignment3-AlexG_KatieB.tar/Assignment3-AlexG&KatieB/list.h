#define PROMPTMAX 32
#define MAXARGS 10


void list ( char *dir );

