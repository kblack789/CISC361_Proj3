#define PROMPTMAX 32
#define MAXARGS 10


char *which(char *command, struct pathelement *pathlist);

