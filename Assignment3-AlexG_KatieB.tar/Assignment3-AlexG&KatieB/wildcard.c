#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <limits.h>
#include <unistd.h>
#include <stdlib.h>
#include <pwd.h>
#include <dirent.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <glob.h>
#include "sh.h"
#include "mylib.h"
#include "wildcard.h"
#define max_buf_size 1024
#define tok_buf_size 64
#define MAX_SIZE 2048
#define command_list_size 13


//a match functions which takes in a char* with a wildcard character (*, ?) and takes in another char * which it compares to. Returns 1 if it is not true. and 0 if it is.
int match(char *first, char * second){
    if (*first == '\0' && *second == '\0')
        return 1;

    if (*first == '*' && *(first+1) != '\0' && *second == '\0')
        return 0;
 
    if (*first == '?' || *first == *second)
        return match(first+1, second+1);
 
    if (*first == '*')
        return match(first+1, second) || match(first, second+1);
    return 0;
}

//Checks if the string inputed has a wildcard variable.
int wildcard_check(char *check_string){
  int i = 0;
  const char *invalid_characters = "*?";
  char *c = check_string;
  while (*c){
    if (strchr(invalid_characters, *c)){
          i = 1;
       }
       c++;
  }
  if (i == 1){
    return 1;
  }
  else{
    return 0;
  }
}

char *list_wildcard (char *dir, char* wildcard){
  //printf("family\n");
  int wild_size=0;
  int space_cnt = 0;
  char *wild_list;
  DIR* direct;
  struct dirent* entryp;
  direct = opendir(dir);
  while((entryp = readdir(direct)) != NULL){
    if (match(wildcard, entryp->d_name) == 1){
      if (strcmp(entryp->d_name, "..") != 0 && strcmp(entryp->d_name, ".") != 0 && strcmp(entryp->d_name, ".git") != 0){
        wild_size += strlen(entryp->d_name);
        space_cnt++;
        if (opendir(entryp->d_name) != NULL){
          list_wildcard(entryp->d_name, wildcard);
        }
      }
      //if (strcmp(entryp->d_name, "..") != 0 || strcmp(entryp->d_name, ".") != 0 || strcmp(entryp->d_name, ".git") != 0) {}
      else{
        //printf("hello\n");
        // if (opendir(entryp->d_name) != NULL){
        //   printf("heo\n");
        //   list_wildcard(entryp->d_name, NULL);
        // }
      }
    }
  }
  //closedir(direct);
  wild_size += space_cnt +1;
  //printf("%d\n", wild_size);
  wild_list = malloc(wild_size);

  DIR* direct1;
  struct dirent* entryp1;
  direct1 = opendir(dir);
  while((entryp1 = readdir(direct1)) != NULL){
    if (match(wildcard, entryp1->d_name) == 1){
      //printf("%s %i\n", entryp1->d_name, strlen(entryp1->d_name));
      if (strcmp(entryp1->d_name, "..") != 0 && strcmp(entryp1->d_name, ".") != 0 && strcmp(entryp1->d_name, ".git") != 0){
        strcat(wild_list, entryp1->d_name);
        strcat(wild_list, " ");
        if (opendir(entryp1->d_name) != NULL){
          list_wildcard(entryp1->d_name, wildcard);
        }
      }
      //if (strcmp(entryp1->d_name, "..") != 0 || strcmp(entryp1->d_name, ".") != 0 || strcmp(entryp1->d_name, ".git") != 0) {}
      else {
        // if (opendir(entryp1->d_name) != NULL){
        //   list_wildcard(entryp1->d_name, NULL);
        // }
      }
    }
  }
  //closedir(direct1);
  //printf("%s\n", wild_list);
  return wild_list;
}

char * command_to_string(char ** args, int arg_count){
  char *command = malloc(512);
  int i = 0;
  while(args[i] != NULL){
    strcat(command, args[i]);
    strcat(command, " ");
    i = i + 1;
  }
  return command;
}


