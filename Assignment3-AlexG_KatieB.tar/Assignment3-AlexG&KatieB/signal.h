#define PROMPTMAX 32
#define MAXARGS 10


void sigintHandler(int sig_num);
void signalSTPHandler(int sig_num);

