//function for shell exit
void shell_exit();

//function for kill process
void kill_process(char **args, int count);

//functions that frees the pathlist when the env of path is changed
void free_pathlist(struct pathelement *head);
